//
//  Note.swift
//  Notes
//
//  Created by Mauricio Reza on 22/09/23.
//

import Foundation
//Tiene que cumplir con los protocolos...
struct Note: Codable {
    var title: String
    var content: String
    
}
