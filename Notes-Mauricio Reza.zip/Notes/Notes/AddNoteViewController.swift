//
//  AddNoteViewController.swift
//  Notes
//
//  Created by Mauricio Reza on 23/09/23.
//

import UIKit

class AddNoteViewController: UIViewController {
    


    @IBOutlet var noteTitle: UITextView!
    @IBOutlet var noteContent: UITextView!
    //una variable que es de tipo Note
    var newNote : Note?
    override func viewDidLoad() {
        super.viewDidLoad()
        if let note = newNote {
                
            print("Editing note with title:", note.title)
                    print("Editing note with content:", note.content)

                    noteTitle.text = note.title
                    noteContent.text = note.content
                } else {
                    print("Creating a new note")
                }
        // Do any additional setup after loading the view.
    }
    
    @IBAction func cancelbuttonPressed(_ sender: UIBarButtonItem) {
        let isModal = self.presentingViewController is UINavigationController
        print("isModal: ",isModal)
        if isModal {
            self.dismiss(animated: true)
        }
        else{
            navigationController?.popViewController(animated: true)
        }
    }
    
    
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        
        //Corresponden con la clase Note.swift
        newNote = Note(title: noteTitle.text, content: noteContent.text!)
       //Add validation Homework
        let destination = segue.destination as! NotesTableViewController
        
        //NECESITAMOS CREAR LA VARIABLE QUE SE LLAMA NOTE EN NOTES
        destination.note = newNote
    
    }
    //Add validation Homework
    
    //valida que el texto tenga algo
        override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
            var perform = false
            if noteTitle.text != "" && noteContent.text != "" {
                    perform = true
                } else {
                    if noteTitle.text == "" {
                        print("El campo de título es requerido")
                        showToast(message: "El título es requerido")
                    }
                    
                    if noteContent.text == "" {
                        print("El campo de contenido es requerido")
                        showToast(message: "El contenido es requerido")
                    }
                }
                
                return perform
            }
    

}
