//
//  NoteViewCell.swift
//  Notes
//
//  Created by Mauricio Reza on 30/09/23.
//


import UIKit

class TaskViewCell: UITableViewCell {
    
    
    @IBOutlet var taskTitle: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
