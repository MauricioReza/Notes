//
//  AddNoteViewController.swift
//  Notes
//
//  Created by Mauricio Reza on 23/09/23.
//

import UIKit

class AddNoteViewController: UIViewController {
    

    let noteManager = NoteManager()
    @IBOutlet var noteTitle: UITextView!
    @IBOutlet var noteContent: UITextView!
    //una variable que es de tipo Note
    var newNote : Note?
    var selectedNote: Note?

    override func viewDidLoad() {
        super.viewDidLoad()
        noteTitle.layer.borderWidth = 0.5 // Ancho del borde
        noteTitle.layer.borderColor = UIColor.gray.cgColor  // Color del borde

        // Agrega bordes a noteContent
        noteContent.layer.borderWidth = 0.5  // Ancho del borde
        noteContent.layer.borderColor = UIColor.gray.cgColor  // Color del borde
        
        // Verifica si hay una nota seleccionada para editar
                if let selectedNote = newNote {
                    print("Editing note with title:", selectedNote.title)
                    print("Editing note with content:", selectedNote.content)
                    
                    noteTitle.text = selectedNote.title
                    noteContent.text = selectedNote.content
                } else {
                    print("Creating a new note")
                }
                // Resto de tu código en viewDidLoad
            }
    
    @IBAction func cancelbuttonPressed(_ sender: UIBarButtonItem) {
        let isModal = self.presentingViewController is UINavigationController
        print("isModal: ",isModal)
        if isModal {
            self.dismiss(animated: true)
        }
        else{
            navigationController?.popViewController(animated: true)
        }
    }
    
    
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

        newNote = Note(title: noteTitle.text, content: noteContent.text!)
        let destination = segue.destination as! NotesTableViewController
                destination.note = newNote
        
    }
    //Add validation Homework
    
    //valida que el texto tenga algo
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        var perform = false

        if noteTitle.text == "" {
            print("El campo de título es requerido")
            showToast(message: "El título es requerido")
        } else if noteContent.text == "" {
            print("El campo de contenido es requerido")
            showToast(message: "El contenido es requerido")
        } else {
            // Ambos campos están completos, permitir el segue
            perform = true
        }

        return perform
    }

    

}
